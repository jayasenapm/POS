For admin

User Name:jaya
password for admin:123

For cashier

User Name:cashier
password :345

Database:shopme
