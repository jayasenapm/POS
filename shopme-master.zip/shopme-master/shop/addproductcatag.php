<div class="content">
<div class="monthly-grid"style="  border-style: solid;
    border-color: red;
	 border-radius: 25px;">
						<div class="panel panel-widget">
							<div class="panel-title">
							  Add New Category
							  
							</div>
							<div class="panel-body">
								<!-- status -->
								<div class="contain">	
									<div class="gantt">
									
									<div class="col-md-12 col-sm-12">					
					
					
					
					
					
					
					
							
							<form role="form" action="addCat.php">
                                                  <div class="form-group">
                                                      <label for="exampleInputEmail1">Category Name:</label>
													  
                                                      <input type="text" class="form-control" id="exampleInputEmail3" name="cname" value="">
                                                  </div>
                                               
                                                 
                                                  <button type="submit" class="btn btn-primary">Save</button>
                                              </form>
							
									
								</div>
								</div>
									</div>
								</div>
								</div>
									</div>
								</div>
								
									
								
									
									